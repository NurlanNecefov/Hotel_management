#ifndef TP3_H
#define TP3_H

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>

typedef struct Client
{
    char *last_name;
    char *first_name;
    int age;
    int num_room;
    struct Client *next; // T_Client -> struct Client (because typedef hasn't defined yet)
} T_Client;

typedef struct Site
{
    char *city;
    int clients;
    T_Client *first;
    struct Site *next;
} T_Site;

typedef struct Hotel
{
    char *name;
    T_Site *first;
} T_Hotel;

T_Client *createClient(char *last_name, char *first_name, int age, int num_room);
T_Site *createSite(char *city);
T_Hotel *createHotel(char *name);

int addClient(T_Site *site, T_Client *client);

int addSite(T_Hotel *hotel, T_Site *site);

void displayHotel(T_Hotel *hotel);

void displaySite(T_Site *site);

int deleteClient(T_Site *site, char *last_name, char *first_name);

int deleteSite(T_Hotel *hotel, char *city);

void searchClients(T_Hotel *hotel, char *critereaName);

void processingfile(T_Hotel *hotel);

// to free the space of malloc
void freeHotel(T_Hotel *hotel);

void freeSite(T_Site *site);

void freeClient(T_Client *client);

static int compareClients(const void *a, const void *b);

void quit(T_Hotel hotel);

#endif
